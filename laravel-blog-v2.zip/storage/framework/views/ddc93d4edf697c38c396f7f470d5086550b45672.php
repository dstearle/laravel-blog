<?php $__env->startSection('content'); ?>

    <div class="jumbotron text-center">

        
        <h1>Welcome To Laravel!</h1>

        <p>This is a cool blog made by me!</p>

        <p>

            
            <a href="/login" role="button" class="btn btn-secondary btn-lg">Login</a>

            
            <a href="/register" role="button" class="btn btn-success btn-lg">Register</a>

        </p>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-blog\resources\views/pages/index.blade.php ENDPATH**/ ?>